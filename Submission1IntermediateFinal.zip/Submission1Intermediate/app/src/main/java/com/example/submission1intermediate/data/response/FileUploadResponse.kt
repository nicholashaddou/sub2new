package com.example.submission1intermediate.data.response


data class FileUploadResponse(
    val error: Boolean,
    val message: String
)
