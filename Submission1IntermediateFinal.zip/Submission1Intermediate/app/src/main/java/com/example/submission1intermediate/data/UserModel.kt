package com.example.submission1intermediate.data

data class UserModel(
    val userId: String,
    val name: String,
    val token : String,
    val isLogin: Boolean
)