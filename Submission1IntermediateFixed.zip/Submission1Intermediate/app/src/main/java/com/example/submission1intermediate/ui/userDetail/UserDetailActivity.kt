package com.example.submission1intermediate.ui.userDetail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.submission1intermediate.data.response.ListStory
import com.example.submission1intermediate.databinding.ActivityUserDetailBinding

class UserDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityUserDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        val userData = intent.getParcelableExtra<ListStory>(EXTRA_DATA) as ListStory
        Glide.with(this)
            .load(userData.photoUrl)
            .into(binding.imageDetail)
        binding.apply {
            nameDetail.text = userData.name
            descriptionDetail.text = userData.description
        }

    }
    companion object{
        const val EXTRA_DATA = "extra_data"
    }
}